declare module TcHmi.Functions.Beckhoff {
    function EventClassesProvider(rowValue: Server.Events.Event, dataIndex: number, rowNumber: number): string[];
}
//# sourceMappingURL=EventClassesProvider.d.ts.map